<?php
require_once '../sm-charts/ajax.php';
$env = json_decode(file_get_contents('../sm-charts/config/env.json'), TRUE);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Stock Market Charts | Documentation</title>

  <link href="../../images/favicons/favicon.ico" rel="shortcut icon">
  <link rel="stylesheet" type="text/css" href="../sm-charts/assets/css/style.css" />
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.10.0/styles/default.min.css">
  <link rel="stylesheet" type="text/css" href="../sm-charts/assets/vendor/select2/css/select2.min.css" />
  <link rel="stylesheet" type="text/css" href="../sm-charts/assets/vendor/amstock/plugins/export/export.css" />
  <link rel="stylesheet" type="text/css" href="../sm-charts/assets/css/style.css" />
  <style>
    h2 {
      border-bottom: 1px solid darkgrey;
    }
    .container {
      width: 80%;
      max-width: 1200px;
      margin-left: auto;
      margin-right: auto;
    }
  </style>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.10.0/highlight.min.js"></script>
  <script src="../sm-charts/assets/vendor/amstock/amcharts.js"></script>
  <script src="../sm-charts/assets/vendor/amstock/serial.js"></script>
  <script src="../sm-charts/assets/vendor/amstock/amstock.js"></script>
  <script src="../sm-charts/assets/vendor/amstock/plugins/export/export.min.js"></script>
  <script src="../sm-charts/assets/vendor/amstock-dataloader/dataloader.min.js"></script>
  <script src="../sm-charts/assets/vendor/select2/js/select2.full.js"></script>
  <script>
    var smcPathToAssets = '..';
    hljs.initHighlightingOnLoad();
  </script>
  <script src="../sm-charts/assets/js/app.min.js"></script>
</head>
<body>
  <div>
    <div class="container">
      <div>
        <h1>Stock Market Charts &mdash; JavaScript / PHP Plugin</h1>
        <h2>System requirements</h2>
        <ul>
          <li>PHP 5.4.x or above (you have <?php print PHP_VERSION?> installed).</li>
        </ul>

        <h2>JavaScript dependencies</h2>
        <ul>
          <li>jQuery</li>
          <li>Select2</li>
          <li>amCharts</li>
        </ul>

        <h2>Setup</h2>
        <p>Copy <b>sm-charts</b> folder to the web root folder of your website (preferably) or any other folder accoring to your website structure.</p>
        <p>To display a stock market chart on your page you need to include few CSS, JavaScript and PHP files. To load necessary CSS / JavaScript assets
          add the following lines to the &lt;HEAD&gt; section of your web page:
        </p>
        <pre>
          <code>&lt;link rel="stylesheet" type="text/css" href="sm-charts/assets/vendor/select2/css/select2.min.css" /&gt;
&lt;link rel="stylesheet" type="text/css" href="sm-charts/assets/vendor/amstock/plugins/export/export.css" /&gt;
&lt;link rel="stylesheet" type="text/css" href="sm-charts/assets/css/style.css" /&gt;
&lt;script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.js"&gt;&lt;/script&gt;
&lt;script src="sm-charts/assets/vendor/amstock/amcharts.js"&gt;&lt;/script&gt;
&lt;script src="sm-charts/assets/vendor/amstock/serial.js"&gt;&lt;/script&gt;
&lt;script src="sm-charts/assets/vendor/amstock/amstock.js"&gt;&lt;/script&gt;
&lt;script src="sm-charts/assets/vendor/amstock/plugins/export/export.min.js"&gt;&lt;/script&gt;
&lt;script src="sm-charts/assets/vendor/amstock-dataloader/dataloader.min.js"&gt;&lt;/script&gt;
&lt;script src="sm-charts/assets/vendor/select2/js/select2.full.js"&gt;&lt;/script&gt;
&lt;script src="sm-charts/assets/js/app.min.js"&gt;&lt;/script&gt;</code>
        </pre>
        <p>If you copied the <b>sm-charts</b> folder to a directory other than the web root
          you also need to specify the path to <b>sm-charts</b> in smcPathToAssets variable by adding the following line <b>before</b>
          the <b>app.min.js</b> file is included (note, that the path should <b>not</b> contain slash at the end):</p>
        <pre>
          <code>&lt;script&gt;var smcPathToAssets = '/path/to/sm-charts/folder';&lt;/script&gt;</code>
        </pre>
        <p>To load necessary PHP classes and functions add this line to the top of your PHP file (path may need to be corrected depending on where the <b>sm-charts</b> folder is copied to):</p>
        <pre>
          <code>&lt;?php require_once 'sm-charts/ajax.php'; ?&gt;</code>
        </pre>
        <p>To display a basic chart add the following HTML code to your page:</p>
        <pre>
          <code>&lt;div id="my-sm-chart" class="smc-chart-container"&gt;&lt;/div&gt;
&lt;script&gt;
  stockMarketChartsPlugin.buildChart(
    'my-sm-chart', // HTML container ID
    'MSFT', // stock symbol
    null, // comma delimited list of assets symbols to automatically add to comparison (applicable when searchMode is set to "comparison")
    '3mo', // range
    '1d' // interval
  );
&lt;/script&gt;</code>
        </pre>
        <p>If everything is done right you will a chart will be displayed on your page:</p>
        <div id="my-sm-chart" class="smc-chart-container"></div>
        <script>
          stockMarketChartsPlugin.buildChart(
            'my-sm-chart',
            'MSFT',
            null,
            '3mo',
            '1d'
          );
        </script>
        <p>To customize the chart you can additionally pass various display settings. Here is an example:</p>
        <pre>
          <code>&lt;div id="my-sm-chart" class="smc-chart-container"&gt;&lt;/div&gt;
&lt;script&gt;
  stockMarketChartsPlugin.buildChart(
    'my-sm-chart2', // HTML container ID
    'GOOG', // stock symbol
    null, // comma delimited list of assets symbols to automatically add to comparison (applicable when searchMode is set to "comparison")
    '6mo', // range
    '1d', // interval
    {
      primaryChartType: "step",
      secondaryChartType: "smoothedLine",
      primaryLineColor: "red",
      searchMode: "search"
    } // settings
  );
&lt;/script&gt;</code>
        </pre>
        <p>The above code will produce this chart:</p>
        <div id="my-sm-chart2" class="smc-chart-container"></div>
        <script>
          stockMarketChartsPlugin.buildChart(
            'my-sm-chart2',
            'GOOG',
            null,
            '2y',
            '1d',
            {
              primaryChartType: "candlestick",
              secondaryChartType: "smoothedLine",
              primaryLineColor: "red",
              defaultPeriod: "1M",
              searchMode: "search"
            }
          );
        </script>
        <p></p>
        <p>Full list of supported settings and their default values is provided below:</p>
        <pre>
          <code>{
  "primaryChartType": "smoothedLine", // Type of stock chart. Possible values: line, smoothedLine, column, step.
  "secondaryChartType": "column", // Type of volume chart. Possible values: line, smoothedLine, column, step, none.
  "logoAlpha": 0.18, // Background logo transparency.
  "width": "100%", // Chart width. Can be set in %, px, em, rem and vw units.
  "height": "500px", // Chart height. Can be set in px, em, rem and vh units.
  "marginTop": 0, // Top margin
  "marginBottom": 0, // Bottom margin
  "marginLeft": 10, // Left margin
  "marginRight": 10, // Right margin
  "primaryPanelTitle": "Price", // Stock chart panel title
  "secondaryPanelTitle": "Volume", // Volume chart panel title
  "fontSize": 14, // Text font size
  "color": "#383838", // Text color
  "primaryLineColor": "#00842c", // Stock chart line and fill color
  "primaryLineColorAlpha": 0.15, // Stock chart fill color transparency
  "secondaryLineColor": "#00842c", // Volume chart line and fill color
  "secondaryLineColorAlpha": 0.15, // Volume chart fill color transparency
  "backgroundColor": "#fff", // Chart container background color
  "gridColor": "#e0e0e0", // Grid color
  "gridAlpha": 0.8, // Grid transparency
  "cursorColor": "#ba0000", // Cursor color
  "cursorAlpha": 0.8, // Cursor transparency
  "scrollbarBackgroundColor": "#e8e8e8", // Scrollbar inactive period background
  "scrollbarSelectedBackgroundColor": "#f7f7f7", // Scrollbar selected period background
  "scrollbarGraphFillColor": "#004c19", // Inactive period fill color
  "scrollbarSelectedGraphFillColor": "#00aa38", // Selected period fill color
  "primaryLineThickness": 2, // Thickness of stock chart line
  "secondaryLineThickness": 1, // Thickness of volume chart line
  "gridThickness": 1, // Grid thickness
  "precision": 2, // Decimal presision
  "thousandsSeparator": ",", // Thousands separator
  "decimalSeparator": ".", // Decimal separator
  "usePrefixes": false, // If enabled prefixes will be used for big and small numbers (e.g. 6k instead of 6,000).
  "mouseWheelZoomEnabled": false, // Enable mouse zoom
  "cursorEnabled": true, // Enable cursor
  "exportEnabled": true, // Enable export button
  "scrollbarEnabled": true, // Enable scrollbar
  "legendEnabled": true, // Enable legend
  "periods": "1D,1W,2W,1M,3M,6M,YTD,1Y,2Y,5Y,ALL", // Predefined periods buttons
  "defaultPeriod": "1W", // Default period
  "searchMode": "comparison" // Search mode, possible options: "search", "comparison", false
}</code>
        </pre>
      </div>

      <h2>Frequently Asked Questions</h2>
      <h3>Where to find an asset symbol?</h3>
      <p>You can use asset search dropdown inside the chart container to find specific assets (stocks, currencies etc).</p>

      <h3>What ranges are supported?</h3>
      <p>The following ranges (periods) are supported: 5d, 1mo, 3mo, 6mo, ytd, 1y, 2y, 5y, 10y, max.</p>

      <h3>What is the polling frequency?</h3>
      <p>
        By default data is cached locally for the period of time specified in "cacheTime" (seconds) attribute (config/env.json).
        When the local cache expires data will be retrieved from the API again.
        It's not recommended to set polling frequency lower than 3600 (1 hour).
      </p>

      <h2>Get support</h2>
      <p></p>
      <p><a href="https://support.financialplugins.com" target="_blank">Contact us</a> if you have any questions.</p>
    </div>
  </div>
</body>
</html>
