Stock Market Charts
-------------------

SYSTEM REQUIREMENTS
-------------------
A web server (such as Apache, Nginx, Microsoft IIS etc) with PHP 5.4.x or above

INSTALLATION
------------
Copy all files to your web server and open documentation/index.php in a browser for further instructions and usage examples.