import 'package:flutter/material.dart';

Color wihitecolor = Colors.white;
Color darkwihitecolor =  Colors.black;

Color blue = const Color(0xff3B82F6);
Color darkblue = const Color(0xff3B82F6);

Color grey = const Color(0xff9EA3AE);
Color darkgrey = const Color(0xff9EA3AE);

Color blck = Colors.white;
Color darkblck = Colors.black;

Color prefixicon = Colors.white;
Color darkprefixicon = const Color(0xff3B82F6);

Color pinauth = const Color(0xffE5E6EB);
Color darkpinauth = const Color(0xffE5E6EB);

Color Investmentcolor = const Color(0xff193590);
Color darkInvestmentcolor = const Color(0xff193590);

Color concirmstockbuycolor = const Color(0xffeff6ff);
Color darkconcirmstockbuycolor = const Color(0xff2A2929FF);






