<div class="header landing_page">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <nav
                    class="navbar navbar-expand-lg navbar-light px-0 justify-content-between"
                >
                    <a class="navbar-brand" href="<?php echo e(url('landing')); ?>"
                        ><img src="./images/logo.png" alt="" />
                        <span>Treemium </span></a
                    >

                    <div class="dashboard_log">
                        <div class="d-flex align-items-center">
                            <div class="header_auth">
                                <a
                                    href="<?php echo e(url('signin')); ?>"
                                    class="btn btn-success mx-2"
                                    >Sign In</a
                                >
                                <a
                                    href="<?php echo e(url('signup')); ?>"
                                    class="btn btn-outline-primary mx-2"
                                    >Sign Up</a
                                >
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
</div>
<?php /**PATH W:\shiful\laravel\treemium\resources\views/components/landings/landing-page-header.blade.php ENDPATH**/ ?>