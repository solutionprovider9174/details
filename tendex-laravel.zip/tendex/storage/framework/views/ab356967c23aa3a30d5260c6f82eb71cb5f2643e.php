<div class="page_title <?php echo e($title === 'true' ? 'd-block' : 'd-none'); ?>">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12">
                <div class="page_title-content">
                    <p>
                        Welcome Back,
                        <span> Maria Pascle</span>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH W:\shiful\laravel\elaenia\resources\views/components/dashboard/title.blade.php ENDPATH**/ ?>