 
<?php $__env->startSection("content"); ?>
<x.layout.sidebar />
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\codeefly\tende\laravel\resources\views/layout/dashboard-layout.blade.php ENDPATH**/ ?>