<div class="sidebar-right">
    <a class="sidebar-right-trigger" href="javascript:void(0)">
        <span><i class="fa fa-cog fa-spin"></i></span>
    </a>
    <div class="sidebar-right-inner">
        <div class="admin-settings">
            <div class="opt-background">
                <p>Font Family</p>
                <select class="form-control" name="theme_font" id="theme_font">
                    <option value="nunito">Nunito</option>
                    <option value="opensans">Open Sans</option>
                </select>
            </div>
            <div>
                <p>Primary Color</p>
                <div class="opt-nav-header-color">
                    <span>
                        <input
                            type="radio"
                            name="navigation_header"
                            value="color_1"
                            class="filled-in chk-col-primary"
                            id="nav_header_color_1"
                        />
                        <label for="nav_header_color_1"></label>
                    </span>
                    <span>
                        <input
                            type="radio"
                            name="navigation_header"
                            value="color_2"
                            class="filled-in chk-col-primary"
                            id="nav_header_color_2"
                        />
                        <label for="nav_header_color_2"></label>
                    </span>
                    <span>
                        <input
                            type="radio"
                            name="navigation_header"
                            value="color_3"
                            class="filled-in chk-col-primary"
                            id="nav_header_color_3"
                        />
                        <label for="nav_header_color_3"></label>
                    </span>
                    <span>
                        <input
                            type="radio"
                            name="navigation_header"
                            value="color_4"
                            class="filled-in chk-col-primary"
                            id="nav_header_color_4"
                        />
                        <label for="nav_header_color_4"></label>
                    </span>
                    <span>
                        <input
                            type="radio"
                            name="navigation_header"
                            value="color_5"
                            class="filled-in chk-col-primary"
                            id="nav_header_color_5"
                        />
                        <label for="nav_header_color_5"></label>
                    </span>
                </div>
            </div>
            <div class="opt-header-color">
                <p>Background Color</p>
                <div>
                    <span>
                        <input
                            type="radio"
                            name="header_bg"
                            value="color_1"
                            class="filled-in chk-col-primary"
                            id="header_color_1"
                        />
                        <label for="header_color_1"></label>
                    </span>
                    <span>
                        <input
                            type="radio"
                            name="header_bg"
                            value="color_2"
                            class="filled-in chk-col-primary"
                            id="header_color_2"
                        />
                        <label for="header_color_2"></label>
                    </span>
                    <span>
                        <input
                            type="radio"
                            name="header_bg"
                            value="color_3"
                            class="filled-in chk-col-primary"
                            id="header_color_3"
                        />
                        <label for="header_color_3"></label>
                    </span>
                    <span>
                        <input
                            type="radio"
                            name="header_bg"
                            value="color_4"
                            class="filled-in chk-col-primary"
                            id="header_color_4"
                        />
                        <label for="header_color_4"></label>
                    </span>
                    <span>
                        <input
                            type="radio"
                            name="header_bg"
                            value="color_5"
                            class="filled-in chk-col-primary"
                            id="header_color_5"
                        />
                        <label for="header_color_5"></label>
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH W:\shiful\laravel\elaenia\resources\views/layouts/settings.blade.php ENDPATH**/ ?>