 <?php $__env->startSection('content'); ?>
<div class="authincation section-padding">
    <div class="container h-100">
        <div class="row justify-content-center h-100 align-items-center">
            <div class="col-xl-5 col-md-6">
                <div class="mini-logo text-center my-5">
                    <img src="./images/m_logo.png" alt="" />
                </div>
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master',['p0'=>'false'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\shiful\laravel\elaenia\resources\views/components/auth/authlayout.blade.php ENDPATH**/ ?>