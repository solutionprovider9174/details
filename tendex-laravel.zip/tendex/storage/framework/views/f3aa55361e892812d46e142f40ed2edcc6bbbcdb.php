<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth.authlayout','data' => []]); ?>
<?php $component->withName('auth.authlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="auth-form card">
        <div class="card-header justify-content-center">
            <h4 class="card-title">Locked</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo url('index'); ?>">
                <div class="form-group mb-4">
                    <label for="">Enter Password</label>
                    <input
                        type="password"
                        class="form-control bg-transparent rounded-0"
                        placeholder="Password"
                    />
                </div>
                <button
                    class="btn-success btn-block btn-lg border-0"
                    type="submit"
                >
                    Unlock
                </button>
            </form>
            <div class="new-account text-center mt-3">
                <a class="text-primary" href="<?php echo e(url('reset')); ?>">
                    <h5>Not Carla Pascle?</h5>
                </a>
            </div>
        </div>
    </div> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH W:\shiful\laravel\elaenia\resources\views/auth/lock.blade.php ENDPATH**/ ?>