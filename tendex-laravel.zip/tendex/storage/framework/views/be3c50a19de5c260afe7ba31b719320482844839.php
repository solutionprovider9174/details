<div class="page_title">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="page_title-content">
                    <p>
                        Welcome Back,
                        <span> Carla Pascle</span>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH W:\shiful\laravel\treemium\resources\views/layouts/dashboard/title.blade.php ENDPATH**/ ?>