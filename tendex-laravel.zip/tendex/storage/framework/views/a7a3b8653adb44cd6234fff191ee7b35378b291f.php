<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dashboard.dashboard-layout','data' => ['title' => 'false']]); ?>
<?php $component->withName('dashboard.dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'false']); ?>
    <div class="verification section-padding">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-xl-5 col-md-6">
                    <div class="auth-form card">
                        <!-- <div class="card-header">
                          <h4 class="card-title">Link a Debit card</h4>
                      </div> -->
                        <div class="card-body">
                            <form
                                action="<?php echo url('verify-step-4'); ?>"
                                class="identity-upload"
                            >
                                <div class="identity-content">
                                    <span class="icon"
                                        ><i class="fa fa-shield"></i
                                    ></span>
                                    <h4>We are verifying your ID</h4>
                                    <p>
                                        Your identity is being verified. We will
                                        email you once your verification has
                                        completed.
                                    </p>
                                </div>

                                <div class="upload-loading text-center mb-3">
                                    <i
                                        class="fa fa-spinner fa-spin fa-3x fa-fw"
                                    ></i>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startSection("extra-js"); ?>
    <script>
        window.setTimeout(function () {
            window.location.href = "verify-step-4";
        }, 2000);
    </script>
    <?php $__env->stopSection(); ?>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH W:\shiful\laravel\treemium\resources\views/dashboard/verify-step-3.blade.php ENDPATH**/ ?>