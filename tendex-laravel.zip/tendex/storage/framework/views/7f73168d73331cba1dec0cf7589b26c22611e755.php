<div class="header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12">
                <nav
                    class="
                        navbar navbar-expand-lg navbar-light
                        px-0
                        justify-content-between
                    "
                >
                    <a class="navbar-brand" href="index"
                        ><img src="./images/w_logo.png" alt="" />
                        <span>Elaenia</span></a
                    >

                    <div class="dashboard_log my-2">
                        <div class="d-flex align-items-center">
                            <div class="account_money">
                                <ul>
                                    <li class="crypto">
                                        <span>0.0025</span>
                                        <i class="cc BTC-alt"></i>
                                    </li>
                                    <li class="usd">
                                        <span>19.93 USD</span>
                                    </li>
                                </ul>
                            </div>
                            <div class="profile_log dropdown">
                                <div class="user" data-toggle="dropdown">
                                    <span class="thumb"
                                        ><i class="la la-user"></i
                                    ></span>
                                    <span class="name">Maria Pascle</span>
                                    <span class="arrow"
                                        ><i class="la la-angle-down"></i
                                    ></span>
                                </div>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a href="accounts" class="dropdown-item">
                                        <i class="la la-user"></i> Account
                                    </a>
                                    <a href="history" class="dropdown-item">
                                        <i class="la la-book"></i> History
                                    </a>
                                    <a href="settings" class="dropdown-item">
                                        <i class="la la-cog"></i> Setting
                                    </a>
                                    <a href="lock" class="dropdown-item">
                                        <i class="la la-lock"></i> Lock
                                    </a>
                                    <a
                                        class="dropdown-item logout"
                                        href="<?php echo e(route('auth.logout')); ?>"
                                    >
                                        <i class="la la-sign-out"></i> Logout
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
</div>
<?php /**PATH W:\shiful\laravel\elaenia\resources\views/components/dashboard/header.blade.php ENDPATH**/ ?>