
<h1>Hello</h1>
<?php echo $__env->make('layout.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\codeefly\tende\laravel\resources\views//index.blade.php ENDPATH**/ ?>