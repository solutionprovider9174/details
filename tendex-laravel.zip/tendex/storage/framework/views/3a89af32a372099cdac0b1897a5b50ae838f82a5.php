<div class="sidebar">
    <div class="menu">
        <ul>
            <li>
                <a
                    href="<?php echo e(url('index')); ?>"
                    data-toggle="tooltip"
                    data-placement="right"
                    title="Home"
                >
                    <span><i class="la la-igloo"></i></span>
                </a>
            </li>
            <li>
                <a
                    href="<?php echo e(url('buy-sell')); ?>"
                    data-toggle="tooltip"
                    data-placement="right"
                    title="Exchange"
                >
                    <span><i class="la la-exchange-alt"></i></span>
                </a>
            </li>
            <li>
                <a
                    href="<?php echo e(url('accounts')); ?>"
                    data-toggle="tooltip"
                    data-placement="right"
                    title="Account"
                >
                    <span><i class="la la-user"></i></span>
                </a>
            </li>
            <li>
                <a
                    href="<?php echo e(url('edit-profile')); ?>"
                    data-toggle="tooltip"
                    data-placement="right"
                    title="Setting"
                    class="setting_"
                >
                    <span><i class="la la-tools"></i></span>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH W:\shiful\laravel\elaenia\resources\views/components/dashboard/sidebar.blade.php ENDPATH**/ ?>