<div id="preloader"><i>.</i><i>.</i><i>.</i></div>
<?php /**PATH W:\codeefly\tende\laravel\resources\views/components/preloader.blade.php ENDPATH**/ ?>