<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Elaenia</title>
        <?php echo $__env->yieldContent('extra-css'); ?>
        <link
            rel="shortcut icon"
            href="<?php echo e(URL::asset('images/favicon.png')); ?>"
            type="image/x-icon"
        />
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/style.css')); ?>" />
    </head>

    <body>
        <div id="preloader">
            <div class="sk-three-bounce">
                <div class="sk-child sk-bounce1"></div>
                <div class="sk-child sk-bounce2"></div>
                <div class="sk-child sk-bounce3"></div>
            </div>
        </div>
        <div id="main-wrapper<?php echo e($p0 === 'true' ? ' pt-0' : ''); ?>">
            <?php echo $__env->yieldContent('content'); ?> <?php echo $__env->make("layouts.settings", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php echo $__env->make("layouts.footer-script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php echo $__env->yieldContent('extra-js'); ?>
    </body>
</html>
<?php /**PATH W:\codeefly\tende\laravel\resources\views/layouts/master.blade.php ENDPATH**/ ?>