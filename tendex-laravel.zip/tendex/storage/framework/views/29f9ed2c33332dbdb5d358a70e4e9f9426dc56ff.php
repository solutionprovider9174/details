<div class="card settings_menu">
    <div class="card-header">
        <h4 class="card-title">Settings</h4>
    </div>
    <div class="card-body">
        <ul class="setting_sidebar">
            <li class="nav-item">
                <a href="<?php echo e(url('/edit-profile')); ?>" class="nav-link">
                    <i class="mdi mdi-account"></i>
                    <span>Edit Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(url('/settings-preferences')); ?>" class="nav-link">
                    <i class="la la-cog"></i>
                    <span>Preferences</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(url('/settings-security')); ?>" class="nav-link">
                    <i class="la la-lock"></i>
                    <span>Security</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(url('/settings-account')); ?>" class="nav-link">
                    <i class="la la-university"></i>
                    <span>Linked Account</span>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH W:\shiful\laravel\treemium\resources\views/components/dashboard/setting-sidebar.blade.php ENDPATH**/ ?>