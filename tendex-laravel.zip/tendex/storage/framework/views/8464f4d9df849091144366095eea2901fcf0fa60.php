<div id="preloader"><i>.</i><i>.</i><i>.</i></div>
<?php /**PATH W:\codeefly\tendex\laravel\resources\views/components/preloader.blade.php ENDPATH**/ ?>