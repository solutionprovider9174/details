<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth.authlayout','data' => []]); ?>
<?php $component->withName('auth.authlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="auth-form card">
        <div class="card-header justify-content-center">
            <h4 class="card-title">Sign in</h4>
        </div>
        <div class="card-body">
            <form
                name="myform"
                class="signin_validate"
                novalidate="novalidate"
                action="<?php echo e(route('auth.check')); ?>"
                method="POST"
            >
                <?php if(Session::get('fail')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session::get('fail')); ?>

                </div>
                <?php endif; ?> <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Email</label>
                    <input
                        type="email"
                        class="form-control"
                        placeholder="hello@example.com"
                        name="email" value="<?php echo e(old('email')); ?>"
                        />
                        <span class="text-danger">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                <div class="form-group">
                    <label>Password</label>
                    <input
                        type="password"
                        class="form-control"
                        placeholder="Password"
                        name="password"
                        value="<?php echo e(old('password')); ?>"
                    />
                    <span class="text-danger">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
                </div>
                <div class="form-row d-flex justify-content-between mt-4 mb-2">
                    <div class="form-group mb-0">
                        <label class="toggle">
                            <input class="toggle-checkbox" type="checkbox" />
                            <div class="toggle-switch"></div>
                            <span class="toggle-label">Remember me</span>
                        </label>
                    </div>
                    <div class="form-group mb-0">
                        <a href="<?php echo e(url('reset')); ?>">Forgot Password?</a>
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-success btn-block">
                        Sign in
                    </button>
                </div>
            </form>
            <div class="new-account mt-3">
                <p>
                    Don't have an account?
                    <a class="text-primary" href="<?php echo e(url('signup')); ?>"
                        >Sign up</a
                    >
                </p>
            </div>
        </div>
    </div>
    <div class="demo-login-text text-center">
        <p class="mb-0"><b>Email:</b> <span>demo@demo.com</span></p>
        <p><b>Password :</b> <span>demo123</span></p>
    </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH W:\shiful\laravel\elaenia\resources\views/auth/signin.blade.php ENDPATH**/ ?>