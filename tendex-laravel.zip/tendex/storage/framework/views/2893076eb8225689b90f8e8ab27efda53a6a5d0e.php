<div class="sidebar">
    <a class="brand-logo" href="<?php echo e(url('index')); ?>">
        <img src="./images/logo.png" alt="" />
        <span>Treemium </span></a
    >

    <div class="menu">
        <ul>
            <li>
                <a href="<?php echo e(url('index')); ?>">
                    <span><i class="mdi mdi-view-dashboard"></i></span>
                    <span class="nav-text">Home</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(url('buy-sell')); ?>">
                    <span><i class="mdi mdi-repeat"></i></span>
                    <span class="nav-text">Exchange</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(url('accounts')); ?>">
                    <span><i class="mdi mdi-account"></i></span>
                    <span class="nav-text">Account</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(url('edit-profile')); ?>" class="setting_">
                    <span><i class="mdi mdi-settings"></i></span>
                    <span class="nav-text">Setting</span>
                </a>
            </li>
        </ul>
    </div>

    <div class="sidebar-footer">
        <div class="social">
            <a href="#"><i class="fa fa-youtube-play"></i></a>
            <a href="#"><i class="fa fa-instagram"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-facebook"></i></a>
        </div>
        <div class="copy_right">© <?php echo e(date("Y")); ?> Quixlab</div>
    </div>
</div>
<?php /**PATH W:\shiful\laravel\treemium\resources\views/components/dashboard/sidebar.blade.php ENDPATH**/ ?>