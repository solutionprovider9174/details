<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth.authlayout','data' => []]); ?>
<?php $component->withName('auth.authlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="auth-form card">
        <div class="card-header justify-content-center">
            <h4 class="card-title">Sign up your account</h4>
        </div>
        <div class="card-body">
            <form
                name="myform"
                onsubmit="event.preventDefault();"
                class="signup_validate"
                novalidate="novalidate"
            >
                <div class="form-group">
                    <label>Username</label>
                    <input
                        type="text"
                        class="form-control"
                        placeholder="username"
                        name="username"
                    />
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input
                        type="email"
                        class="form-control"
                        placeholder="hello@example.com"
                        name="email"
                    />
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input
                        type="password"
                        class="form-control"
                        placeholder="Password"
                        name="password"
                    />
                </div>
                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-success btn-block">
                        Sign up
                    </button>
                </div>
            </form>
            <div class="new-account mt-3">
                <p>
                    Already have an account?
                    <a class="text-primary" href="<?php echo e(url('signin')); ?>"
                        >Sign in</a
                    >
                </p>
            </div>
        </div>
    </div> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH W:\shiful\laravel\treemium\resources\views/auth/signup.blade.php ENDPATH**/ ?>