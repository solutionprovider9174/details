 <?php $__env->startSection("content"); ?>
<?php $__env->startComponent('components.landing-page-header'); ?> <?php if (isset($__componentOriginal457db2162a0a2d3dd4f2da3480d0db07c8751cb7)): ?>
<?php $component = $__componentOriginal457db2162a0a2d3dd4f2da3480d0db07c8751cb7; ?>
<?php unset($__componentOriginal457db2162a0a2d3dd4f2da3480d0db07c8751cb7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('components.landing-page-titlte'); ?> About Us <?php if (isset($__componentOriginal046c8e41124777e6c12ebeb015e6f9777e2207e2)): ?>
<?php $component = $__componentOriginal046c8e41124777e6c12ebeb015e6f9777e2207e2; ?>
<?php unset($__componentOriginal046c8e41124777e6c12ebeb015e6f9777e2207e2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<div class="about py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-9">
                <div class="about_content">
                    <div class="our_vision">
                        <h3>OUR VISION</h3>
                        <p>
                            The growth of virtual items and microtransactions
                            have been enormous over the last few years. The
                            prices for these items or microtransactions are
                            often twice the price of the game itself. We
                            understand people want these exclusive in-game
                            rewards, but we also see how they are too expensive
                            for many. Therefore we came up with the idea,
                            Treemium .
                        </p>
                        <p>
                            We started providing a service directly targeted
                            towards the game Counter-Strike: Global Offensive,
                            however, we quickly came to realize this had the
                            potential to reach a much broader audience. Now we
                            have expanded our service for not only gamers, but
                            also others that want gift cards to shop at their
                            favorite place, Treemium ocurrencies to start their
                            Treemium o adventure, or just direct PayPal cash to
                            spend on whatever you want.
                        </p>
                        <p>
                            We’re excited for what the future has to bring, and
                            we will continuously be pushing out updates and new
                            features to keep Treemium the leading platform in
                            the GPT industry
                        </p>
                        <p>
                            The growth of virtual items and microtransactions
                            have been enormous over the last few years. The
                            prices for these items or microtransactions are
                            often twice the price of the game itself. We
                            understand people want these exclusive in-game
                            rewards, but we also see how they are too expensive
                            for many. Therefore we came up with the idea,
                            Treemium .
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\shiful\laravel\treemium\resources\views/about.blade.php ENDPATH**/ ?>