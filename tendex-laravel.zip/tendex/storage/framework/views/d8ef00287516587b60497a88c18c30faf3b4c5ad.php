<div class="header">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <nav class="navbar">
                    <div class="header-search d-flex align-items-center">
                        <a class="brand-logo mr-3" href="<?php echo e(url('index')); ?>">
                            <img src="./images/logo.png" alt="" width="30" />
                        </a>
                        <form action="#">
                            <div class="input-group">
                                <input
                                    type="text"
                                    class="form-control"
                                    placeholder="Search"
                                />
                                <div class="input-group-append">
                                    <span
                                        class="input-group-text"
                                        id="basic-addon2"
                                        ><i class="fa fa-search"></i
                                    ></span>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="dashboard_log">
                        <div class="d-flex align-items-center">
                            <div class="profile_log dropdown">
                                <div class="user" data-toggle="dropdown">
                                    <span class="thumb"
                                        ><i class="mdi mdi-account"></i
                                    ></span>
                                    <span class="name">Carla Pascle</span>
                                    <span class="arrow"
                                        ><i class="la la-angle-down"></i
                                    ></span>
                                </div>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a
                                        href="<?php echo e(url('accounts')); ?>"
                                        class="dropdown-item"
                                    >
                                        <i class="mdi mdi-account"></i> Account
                                    </a>
                                    <a
                                        href="<?php echo e(url('history')); ?>"
                                        class="dropdown-item"
                                    >
                                        <i class="la la-book"></i> History
                                    </a>
                                    <a
                                        href="<?php echo e(url('edit-profile')); ?>"
                                        class="dropdown-item"
                                    >
                                        <i class="la la-cog"></i> Setting
                                    </a>
                                    <a
                                        href="<?php echo e(url('lock')); ?>"
                                        class="dropdown-item"
                                    >
                                        <i class="la la-lock"></i> Lock
                                    </a>
                                    <a
                                        href="<?php echo e(url('signin')); ?>"
                                        class="dropdown-item logout"
                                    >
                                        <i class="la la-sign-out"></i> Logout
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
</div>
<?php /**PATH W:\shiful\laravel\treemium\resources\views/components/dashboard/header.blade.php ENDPATH**/ ?>