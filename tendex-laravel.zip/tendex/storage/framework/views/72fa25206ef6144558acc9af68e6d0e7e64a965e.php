<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth.authlayout','data' => []]); ?>
<?php $component->withName('auth.authlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="auth-form card">
        <div class="card-header justify-content-center">
            <h4 class="card-title">Reset password</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo url('signin'); ?>">
                <div class="form-group">
                    <label>Email</label>
                    <input
                        type="email"
                        class="form-control"
                        value="hello@example.com"
                    />
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-success btn-block">
                        Reset
                    </button>
                </div>
            </form>
            <div class="new-account mt-3">
                <p class="mb-1">Don't Received?</p>
                <a class="text-primary" href="<?php echo e(url('reset')); ?>">Resend </a>
            </div>
        </div>
    </div> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH W:\shiful\laravel\treemium\resources\views/auth\reset.blade.php ENDPATH**/ ?>