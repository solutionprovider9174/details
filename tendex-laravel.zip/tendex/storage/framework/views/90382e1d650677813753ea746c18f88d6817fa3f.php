<?php $__env->startComponent("components.auth/authlayout"); ?>
<div class="auth-form card">
    <div class="card-header justify-content-center">
        <h4 class="card-title">Locked</h4>
    </div>
    <div class="card-body">
        <form action="<?php echo url('index'); ?>">
            <div class="form-group mb-4">
                <label for="">Enter Password</label>
                <input
                    type="password"
                    class="form-control bg-transparent rounded-0"
                    placeholder="Password"
                />
            </div>
            <button class="btn-success btn-block btn-lg border-0" type="submit">
                Unlock
            </button>
        </form>
        <div class="new-account text-center mt-3">
            <a class="text-primary" href="<?php echo e(url('reset')); ?>">
                <h5>Not Carla Pascle?</h5>
            </a>
        </div>
    </div>
</div>
<?php if (isset($__componentOriginal8064a05095974d77964cc17ba3c129932d0f9a50)): ?>
<?php $component = $__componentOriginal8064a05095974d77964cc17ba3c129932d0f9a50; ?>
<?php unset($__componentOriginal8064a05095974d77964cc17ba3c129932d0f9a50); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH W:\shiful\laravel\treemium\resources\views/auth\lock.blade.php ENDPATH**/ ?>