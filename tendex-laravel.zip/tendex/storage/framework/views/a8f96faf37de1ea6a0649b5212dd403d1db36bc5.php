<script src="<?php echo e(URL::asset('vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Owl carousel -->
<script src="<?php echo e(URL::asset('vendor/owlcarousel/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/plugins/owl-carousel-init.js')); ?>"></script>

<!-- Scroll -->
<script src="<?php echo e(URL::asset('vendor/scrollit/scrollIt.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/plugins/scrollit-init.js')); ?>"></script>

<!-- Chart sparkline plugin files -->
<script src="<?php echo e(URL::asset('vendor/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/plugins/sparkline-init.js')); ?>"></script>

<!--  flot-chart js -->
<script src="<?php echo e(URL::asset('vendor/apexchart/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('vendor/apexchart/apexchart-init.js')); ?>"></script>
<script src="<?php echo e(URL::asset('vendor/apexchart/apexchart2-init.js')); ?>"></script>

<!-- ui -->
<script src="<?php echo e(URL::asset('vendor/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/plugins/jquery-ui-init.js')); ?>"></script>

<!-- Validation -->
<script src="<?php echo e(URL::asset('vendor/validator/jquery.validate.js')); ?>"></script>
<script src="<?php echo e(URL::asset('vendor/validator/validator-init.js')); ?>"></script>

<!-- Popup -->
<script src="<?php echo e(URL::asset('vendor/magnific-popup/magnific-popup.js')); ?>"></script>
<script src="<?php echo e(URL::asset('vendor/magnific-popup/magnific-popup-init.js')); ?>"></script>

<script src="<?php echo e(URL::asset('js/scripts.js')); ?>"></script>
<?php /**PATH W:\shiful\laravel\treemium\resources\views/layouts/footer-script.blade.php ENDPATH**/ ?>