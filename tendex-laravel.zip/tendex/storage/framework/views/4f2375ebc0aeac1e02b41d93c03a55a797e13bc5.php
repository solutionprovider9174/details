<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth.authlayout','data' => []]); ?>
<?php $component->withName('auth.authlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="auth-form card">
        <div class="card-body">
            <a class="page-back text-muted" href="<?php echo e(url('otp-1')); ?>">
                <span><i class="fa fa-angle-left"></i></span> Back</a
            >
            <h3 class="text-center">OTP Verification</h3>
            <p class="text-center mb-5">
                We will send one time code on this number
            </p>
            <form action="<?php echo url('/index'); ?>" <div class="form-group">
                <label>Your OTP Code</label>
                <div class="input-group mb-3">
                    <input
                        type="text"
                        class="form-control text-center font-weight-bold"
                        value="11 22 33"
                    />
                </div>

                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-success btn-block">
                        Send
                    </button>
                </div>
            </form>
            <div class="new-account mt-3 d-flex justify-content-between">
                <p>You dont recommended to save password to browsers!</p>
            </div>
        </div>
    </div> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH W:\shiful\laravel\treemium\resources\views/auth\otp-2.blade.php ENDPATH**/ ?>