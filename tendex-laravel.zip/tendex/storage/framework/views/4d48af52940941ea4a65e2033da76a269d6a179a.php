<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dashboard.dashboard-layout','data' => ['title' => 'false']]); ?>
<?php $component->withName('dashboard.dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'false']); ?>
    <div class="verification section-padding mb-80">
        <div class="container h-100">
            <div
                class="row justify-content-center h-100 align-items-center my-5"
            >
                <div class="col-xl-5 col-md-6">
                    <div class="auth-form card">
                        <div class="card-header">
                            <h4 class="card-title">Link a bank account</h4>
                        </div>
                        <div class="card-body">
                            <form
                                action="<?php echo url('verify-step-6'); ?>"
                                class="identity-upload"
                            >
                                <div class="form-row">
                                    <div class="form-group col-xl-12">
                                        <label class="mr-sm-2"
                                            >Routing number
                                        </label>
                                        <input
                                            type="text"
                                            class="form-control"
                                            placeholder="25487"
                                        />
                                    </div>
                                    <div class="form-group col-xl-12">
                                        <label class="mr-sm-2"
                                            >Account number
                                        </label>
                                        <input
                                            type="text"
                                            class="form-control"
                                            placeholder="36475"
                                        />
                                    </div>
                                    <div class="form-group col-xl-12">
                                        <label class="mr-sm-2"
                                            >Fulll name
                                        </label>
                                        <input
                                            type="text"
                                            class="form-control"
                                            placeholder="Carla Pascle"
                                        />
                                    </div>
                                    <div class="form-group col-xl-12">
                                        <img
                                            src="./images/routing.png"
                                            alt=""
                                            class="img-fluid"
                                        />
                                    </div>

                                    <div class="text-center col-12">
                                        <a
                                            href="<?php echo e(url('verify-step-5')); ?>"
                                            class="btn btn-primary mx-2"
                                            >Back</a
                                        >
                                        <button
                                            type="submit"
                                            class="btn btn-success mx-2"
                                        >
                                            Save
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH W:\shiful\laravel\elaenia\resources\views/dashboard/add-bank-acc.blade.php ENDPATH**/ ?>