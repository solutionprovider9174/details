

<?php $__env->startSection('content'); ?>
<div class="header landing_page">
     <div class="container">
          <div class="row">
          <div class="col-xl-12">
               <nav class="navbar navbar-expand-lg navbar-light px-0">
                    <a class="navbar-brand" href="<?php echo e(url('demo')); ?>"><img src="./images/logo.png" alt="">
                         <span>Treemium </span></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                         <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                         <ul class="navbar-nav">
                              <li class="nav-item">
                              <a class="nav-link" href="#" data-scroll-nav="0">Home</a>
                              </li>
                              <li class="nav-item">
                              <a class="nav-link" href="#" data-scroll-nav="1">Demo</a>
                              </li>
                              <li class="nav-item">
                              <a class="nav-link" href="#" data-scroll-nav="2">Support</a>
                              </li>
                         </ul>
                    </div>
                    <div class="dashboard_log">
                         <div class="d-flex align-items-center">
                              <div class="header_auth">
                              <a href="#" class="btn btn-primary">Buy</a>
                              </div>
                         </div>
                    </div>
               </nav>
          </div>
          </div>
     </div>
</div>

<div class="intro section-padding position-relative" id="intro" data-scroll-index="0">
     <div class="container">
          <div class="row align-items-center justify-content-between">
          <div class="col-xl-6 col-md-6">
               <div class="intro-content">
                    <h2>The complete Treemium ocurrency Exchange Laravel Template</h2>
                    <p>Sign in, Signup, Phone and ID card verification, One time password verify and add bank, debit card settings and profile etc pages included. </p>
                    <a href="#" class="btn btn-primary" data-scroll-nav="1">View Demo</a>
               </div>
          </div>
          <div class="col-xl-6 col-md-6 py-md-5">
               <div class="demo_img intro-img">
                    <img src="./images/portfolio.jpg" alt="" class="img-fluid">
               </div>
          </div>
          </div>
     </div>
</div>

<div class="market section-padding page-section" data-scroll-index="1">
     <div class="container">
          <div class="row py-lg-5 justify-content-center">
          <div class="col-xl-7">
               <div class="section_heading">
                    <span>Explore</span>
                    <h3>The Complete Treemium  Crafted Design Pages</h3>
               </div>
          </div>
          </div>
          <div class="row">
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('landing')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/landing.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Landing Page</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('index')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/dashboard.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Dashboard</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('buy-sell')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/buy-sell.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Buy and Sell</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('accounts')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/accounts.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Accounts</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('edit-profile')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/edit-profile.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Edit Profile</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('settings-preferences')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/preferences.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Preferences</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('settings-security')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/security.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Security</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('settings-account')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/linked-account.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Linked Account</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('history')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/history.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>History</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('signin')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/signin.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Signin</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('signup')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/signup.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Signup</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('reset')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/reset.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Reset</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('lock')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/lock.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Locked</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('otp-1')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/otp-phone.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>OTP Number</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('otp-2')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/otp-code.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>OTP Code</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('verify-step-1')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/verify-id.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Verify ID</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('verify-step-2')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/upload-id.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Upload ID</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('verify-step-3')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/id-verifing.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>ID Verifying</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('verify-step-4')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/id-verified.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>ID Verified</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('add-debit-card')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/add-debit-card.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Add Debit Card</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('verify-step-6')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/success.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Success</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('verify-step-5')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/choose-account.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Recommendation</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('add-bank-acc')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/add-bank.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Add Bank Account</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('about')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/about.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>About US</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('privacy-policy')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/privacy.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Privacy Policy</h5>
               </div>
          </div>
          <div class="col-xl-4 col-md-6 col-sm-6">
               <div class="demo_img">
                    <a href="<?php echo e(url('term-condition')); ?>" target="_blank">
                         <div class="img-wrap">
                              <img src="./images/demo/terms.jpg" alt="" class="img-fluid">
                         </div>
                    </a>
                    <h4>Terms & Condition</h5>
               </div>
          </div>
          </div>
     </div>
</div>

<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.master',['p0'=>'true'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\shiful\laravel\treemium\resources\views/demo.blade.php ENDPATH**/ ?>