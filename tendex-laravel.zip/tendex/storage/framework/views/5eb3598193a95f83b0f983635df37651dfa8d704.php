<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth.authlayout','data' => []]); ?>
<?php $component->withName('auth.authlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="auth-form card">
        <div class="card-body">
            <a class="page-back text-muted" href="<?php echo e(url('signin')); ?>">
                <span><i class="fa fa-angle-left"></i></span> Back</a
            >
            <h3 class="text-center">OTP Verification</h3>
            <p class="text-center mb-5">
                We will send one time code on this number
            </p>
            <form action="<?php echo url('/otp-2'); ?>" <div class="form-group">
                <label>Your phone number</label>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text pl-4 pr-4"
                            ><i class="fa fa-phone"></i
                        ></span>
                    </div>
                    <input
                        type="text"
                        class="form-control"
                        value="+1 12365480"
                    />
                </div>

                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-success btn-block">
                        Send
                    </button>
                </div>
            </form>
            <div class="new-account mt-3 d-flex justify-content-between">
                <p>
                    Don't get code?
                    <a class="text-primary" href="<?php echo e(url('otp-1')); ?>">Resend</a>
                </p>
            </div>
        </div>
    </div> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH W:\shiful\laravel\elaenia\resources\views/auth/otp-1.blade.php ENDPATH**/ ?>