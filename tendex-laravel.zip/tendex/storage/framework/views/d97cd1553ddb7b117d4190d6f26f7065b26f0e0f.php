<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.landing.landing-layout','data' => []]); ?>
<?php $component->withName('landing.landing-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="contact-form section-padding">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-7">
                    <div class="section-title text-center">
                        <span>Ask Question</span>
                        <h2>Let us hear from you directly!</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-4 col-md-4 col-sm-12">
                    <div class="info-list">
                        <h4 class="mb-3">Address</h4>
                        <ul>
                            <li>
                                <i class="fa fa-map-marker"></i> California, USA
                            </li>
                            <li>
                                <i class="fa fa-phone"></i> (+880) 1243 665566
                            </li>
                            <li>
                                <i class="fa fa-envelope"></i> hello@example.com
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-8 col-md-8 col-sm-12">
                    <form name="myform" class="contact_validate">
                        <div class="row">
                            <div class="col-12 col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">
                                        Full name
                                    </label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        id="contactName"
                                        placeholder="Full name"
                                        name="firstname"
                                    />
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <div class="mb-3">
                                    <label class="form-label"> Email </label>
                                    <input
                                        type="email"
                                        class="form-control"
                                        name="email"
                                        placeholder="hello@domain.com"
                                    />
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="mb-3">
                                    <textarea
                                        class="form-control p-3"
                                        name="message"
                                        rows="5"
                                        placeholder="Tell us what we can help you with!"
                                    ></textarea>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary px-4 py-2">
                            Send message
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 p-0">
            <div id="map-canvas"></div>
        </div>
    </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH W:\codeefly\tendex\laravel\resources\views//pages/landing/contact.blade.php ENDPATH**/ ?>