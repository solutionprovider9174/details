<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dashboard.dashboard-layout','data' => []]); ?>
<?php $component->withName('dashboard.dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <div class="content-body">
          <div class="container">
            <div class="row">
              <div class="col-xxl-12 col-xl-12">
                <div class="page-title">
                  <h4><?php echo e($pageTitle); ?></h4>
                </div>
                <div class="card">
                  <div class="card-header">
                    <div class="settings-menu">
          <a href="<?php echo e(url('settings-profile')); ?>">Profile</a>
          <a href="<?php echo e(url('settings-application')); ?>">Application</a>
          <a href="<?php echo e(url('settings-security')); ?>">Security</a>
          <a href="<?php echo e(url('settings-activity')); ?>">Activity</a>
          <a href="<?php echo e(url('settings-privacy')); ?>">Privacy</a>
          <a href="<?php echo e(url('settings-payment-method')); ?>">Payment Method</a>
          <a href="<?php echo e(url('settings-api')); ?>">API</a>
          <a href="<?php echo e(url('settings-fees')); ?>">Fees</a>
      </div>
                  </div>
                  <?php echo e($slot); ?>

                </div>
              </div>
            </div>
          </div>
        </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH W:\codeefly\tende\laravel\resources\views/components/dashboard/settings-layout.blade.php ENDPATH**/ ?>