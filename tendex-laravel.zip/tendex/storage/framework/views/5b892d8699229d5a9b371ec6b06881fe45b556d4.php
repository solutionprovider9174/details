<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-layout','data' => []]); ?>
<?php $component->withName('auth-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?><div class="authincation section-padding">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-xl-5 col-md-6">
                    <div class="mini-logo text-center my-4">
                        <a href="<?php echo e(url('/')); ?>"
                            ><img src="./images/logo.png" alt=""
                        /></a>
                        <h4 class="card-title mt-5">Create your account</h4>
                    </div>
                    <div class="auth-form card">
                        <div class="card-body">
                            <form
                                name="myform"
                                class="signin_validate row g-3"
                                action="<?php echo e(url('verify-email')); ?>"
                            >
                                <div class="col-12">
                                    <input
                                        type="text"
                                        class="form-control"
                                        placeholder="Name"
                                        name="name"
                                    />
                                </div>
                                <div class="col-12">
                                    <input
                                        type="email"
                                        class="form-control"
                                        placeholder="hello@example.com"
                                        name="email"
                                    />
                                </div>
                                <div class="col-12">
                                    <input
                                        type="password"
                                        class="form-control"
                                        placeholder="Password"
                                        name="password"
                                    />
                                </div>
                                <div class="col-12">
                                    <div class="form-check form-switch">
                                        <input
                                            class="form-check-input"
                                            type="checkbox"
                                            id="flexSwitchCheckDefault"
                                        />
                                        <label
                                            class="form-check-label"
                                            for="flexSwitchCheckDefault"
                                        >
                                            I certify that I am 18 years of age
                                            or older, and agree to the
                                            <a href="#" class="text-primary"
                                                >User Agreement</a
                                            >
                                            and
                                            <a href="#" class="text-primary"
                                                >Privacy Policy</a
                                            >.
                                        </label>
                                    </div>
                                </div>

                                <div class="d-grid gap-2">
                                    <button
                                        type="submit"
                                        class="btn btn-primary"
                                    >
                                        Create account
                                    </button>
                                </div>
                            </form>
                            <div class="text-center">
                                <p class="mt-3 mb-0">
                                    <a
                                        class="text-primary"
                                        href="<?php echo e(url('signin')); ?>"
                                        >Sign in</a
                                    >
                                    to your account
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH W:\codeefly\tende\laravel\resources\views//pages/signup.blade.php ENDPATH**/ ?>