<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-layout','data' => []]); ?>
<?php $component->withName('auth-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="authincation section-padding">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-xl-5 col-md-6">
                    <div class="mini-logo text-center my-4">
                        <a href="<?php echo e(url('/')); ?>"
                            ><img src="./images/logo.png" alt=""
                        /></a>
                        <h4 class="card-title mt-5">Sign in to Tende</h4>
                    </div>
                    <div class="auth-form card">
                        <div class="card-body">
                            <form
                                name="myform"
                                class="signin_validate row g-3"
                                action="<?php echo e(route('auth.check')); ?>"
                                method="POST"
                            >
                                <?php if(Session::get('fail')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(Session::get('fail')); ?>

                                </div>
                                <?php endif; ?> <?php echo csrf_field(); ?>
                                <div class="col-12">
                                    <input
                                        type="email"
                                        class="form-control"
                                        placeholder="hello@example.com"
                                        name="email"
                                        value="<?php echo e(old('email')); ?>"
                                    />
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="col-12">
                                    <input
                                        type="password"
                                        class="form-control"
                                        placeholder="Password"
                                        name="password"
                                        value="<?php echo e(old('password')); ?>"
                                    />
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="col-6">
                                    <div class="form-check form-switch">
                                        <input
                                            class="form-check-input"
                                            type="checkbox"
                                            id="flexSwitchCheckDefault"
                                        />
                                        <label
                                            class="form-check-label"
                                            for="flexSwitchCheckDefault"
                                            >Remember me</label
                                        >
                                    </div>
                                </div>
                                <div class="col-6 text-right">
                                    <a href="<?php echo e(url('reset')); ?>"
                                        >Forgot Password?</a
                                    >
                                </div>
                                <div class="d-grid gap-2">
                                    <button
                                        type="submit"
                                        class="btn btn-primary"
                                    >
                                        Sign in
                                    </button>
                                </div>
                            </form>
                            <p class="mt-3 mb-0">
                                Don't have an account?
                                <a
                                    class="text-primary"
                                    href="<?php echo e(url('signup')); ?>"
                                    >Sign up</a
                                >
                            </p>
                            <div class="mt-2">
                                <small class="mb-0 me-2"
                                    ><b>Email :</b> demo@demo.com</small
                                >
                                <small><b>Password :</b> demo123</small>
                            </div>
                        </div>
                    </div>
                    <div class="privacy-link">
                        <a href="<?php echo e(url('signup')); ?>"
                            >Have an issue with 2-factor authentication?</a
                        >
                        <br />
                        <a href="<?php echo e(url('signup')); ?>">Privacy Policy</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH W:\codeefly\tende\laravel\resources\views/pages/signin.blade.php ENDPATH**/ ?>