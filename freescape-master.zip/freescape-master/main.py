import bpy 
import os
import re 
import json
import sys
import math
from pathlib import Path
sys.path.append(os.getcwd())

import obj_map

#creates out folder for renders
OUT_PATH = "out"
if not os.path.exists(OUT_PATH):
    os.mkdir(OUT_PATH)

result_coll = "output"
data = None

def render(output_dir, output_filename = 'render.jpg'):  
    bpy.context.scene.render.filepath = os.path.join(os.path.abspath(output_dir), output_filename)
    bpy.ops.render.render(write_still = True)

def deactivate_obj(obj):
    obj.hide_render = True
    obj.hide_select = True
    obj.hide_viewport = True

def activate_obj(obj):
    obj.hide_render = False
    obj.hide_select = False
    obj.hide_viewport = False

def deactivate_collections():
    for x in bpy.data.collections:
        if x.name != result_coll:
            deactivate_obj(x)
            for y in x.objects:
                deactivate_obj(y)

def activate_collections():
    for x in bpy.data.collections:
        activate_obj(x)
        for y in x.objects:
            activate_obj(y)


def move_obj_to_collection(obj_name, target = result_coll):
    if obj_name == "None":
        return

    try:
        for i in getChildren(bpy.data.objects[obj_name]):
            move_obj_to_collection(i.name)
        obj = bpy.data.objects[obj_name].copy()
        coll_target = bpy.data.collections[target]
        coll_target.objects.link(obj)
        activate_obj(obj)
        if len(getChildren(obj)) > 0:
            print(getChildren(obj))
            for i in getChildren(obj):
                move_obj_to_collection(i)
    except:
        print("{} not found".format(obj_name))
        return
    

def delete_collection(collection):
    for obj in collection.objects:
        bpy.data.objects.remove(obj, do_unlink=True)
    
    bpy.data.collections.remove(collection)


def clear_output():
    collection = bpy.data.collections[result_coll]
    for x in collection.objects:
        bpy.data.objects.remove(x, do_unlink=True)
    for x in collection.children:
        delete_collection(x)

def getChildren(obj): 
    children = [] 
    for ob in bpy.data.objects: 
        if ob.parent == obj: 
            children.append(ob) 
    return children 

def scale_obj(obj, value = 1):
    obj.scale = (value, value, value)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.transform_apply(location = False, scale = True, rotation = False)


def main():   
    counter = 0

    #open blend file
    bpy.ops.wm.open_mainfile(filepath=os.path.abspath("./scene.blend"))

    bpy.context.scene.render.film_transparent = True

    #open and load json file
    with open("./data.json", "r") as file:
        data = json.load(file)

    #create render collection within blender file
    collection = bpy.context.blend_data.collections.new(name=result_coll)
    bpy.context.scene.collection.children.link(collection)

    #sets armature to pose mode
    armature = bpy.data.objects["Armature"]
    armature.data.pose_position = 'POSE'
    # scale_obj(armature)


    #loop through json file
    for x in data:
        #activates all objects and collections
        activate_collections()

        for attr in x["attributes"]:
            print(attr["value"])
            # finds the traits of current json object and moves the to output collection
            if attr["trait_type"] == "outfit":        
                move_obj_to_collection(obj_map.oufit[attr["value"]])
            if attr["trait_type"] == "head":        
                move_obj_to_collection(obj_map.head[attr["value"]])
            if attr["trait_type"] == "hat":        
                move_obj_to_collection(obj_map.hat[attr["value"]])
            if attr["trait_type"] == "boots":        
                move_obj_to_collection(obj_map.boots[attr["value"]])
            if attr["trait_type"] == "accessory":        
                move_obj_to_collection(obj_map.accessory[attr["value"]])
            if attr["trait_type"] == "back":        
                move_obj_to_collection(obj_map.back[attr["value"]])
            if attr["trait_type"] == "torso":        
                move_obj_to_collection(obj_map.torso[attr["value"]])
            if attr["trait_type"] == "arms":        
                move_obj_to_collection(obj_map.arms[attr["value"]])
            if attr["trait_type"] == "garment":        
                move_obj_to_collection(obj_map.garment[attr["value"]])
            if attr["trait_type"] == "guns":        
                move_obj_to_collection(obj_map.guns[attr["value"]])
            if attr["trait_type"] == "backgrounds": 
                bpy.context.scene.frame_set(obj_map.background[attr["value"]])  # set frame with pose
            

        #sets objects as children of armature
        for i in bpy.data.collections[result_coll].objects:
            if len(i.modifiers) > 0:
                i.modifiers["Armature"].object = armature
                i.modifiers["Armature"].use_bone_envelopes = True
            i.parent = armature

        # for debugging
        for i in bpy.data.collections["output"].objects:
            print(i.name)

        #deactivates all other collections except for output
        deactivate_collections() 

        #renders the image then clears the output collection
        render(output_dir = "./out", output_filename = str(counter))
        clear_output()
        counter+=1

    
    
if __name__ == "__main__":
    main()
