node cowboys.js
blender -b -P "main.py"