oufit = {
    "Yuma": "Yuma" ,
    "Tombstone": "Tombstone" ,
    "Durango (Dual Brass Belt)": "Durango (Dual Brass Belt)" ,
    "Durango (Dual Silver Belt)": "Durango (Dual Silver Belt)" ,
    "Escalante (Dual Brass Belt)": "Escalante (Dual Brass Belt)" ,
    "Escalante (Dual Silver Belt)": "Escalante (Dual Silver Belt)" ,
    "Sedona (Dual Brass Belt)": "Sedona (Dual Brass Belt)" ,
    "Sedona (Dual Silver Belt)": "Sedona (Dual Silver Belt)" ,
}

head = {
    #DESPERADO
    #=============================================================================
    "Gold Desperado (Blue Eyes)": "Gold Desperado (Blue Eyes)",
    "Gold Desperado (Orange Eyes)": "Gold Desperado (Orange Eyes)",
    "Gold Desperado (Red Eyes)": "Gold Desperado (Red Eyes)",
    "Gold Desperado (Purple Eyes)": "Gold Desperado (Purple Eyes)",

    "Silver Desperado (Blue Eyes)": "Silver Desperado (Blue Eyes)",
    "Silver Desperado (Orange Eyes)": "Silver Desperado (Orange Eyes)",
    "Silver Desperado (Red Eyes)": "Silver Desperado (Red Eyes)",
    "Silver Desperado (Purple Eyes)": "Silver Desperado (Purple Eyes)",

    "Bronze Desperado (Blue Eyes)": "Bronze Desperado (Blue Eyes)",
    "Bronze Desperado (Orange Eyes)": "Bronze Desperado (Orange Eyes)",
    "Bronze Desperado (Red Eyes)": "Bronze Desperado (Red Eyes)",
    "Bronze Desperado (Purple Eyes)": "Bronze Desperado (Purple Eyes)",

    #PATHFINDER
    #=============================================================================
    "Gold Pathfinder (Blue Eyes)": "Gold Pathfinder (Blue Eyes)",
    "Gold Pathfinder (Orange Eyes)": "Gold Pathfinder (Orange Eyes)",
    "Gold Pathfinder (Red Eyes)": "Gold Pathfinder (Red Eyes)",
    "Gold Pathfinder (Purple Eyes)": "Gold Pathfinder (Purple Eyes)",

    "Silver Pathfinder (Blue Eyes)": "Silver Pathfinder (Blue Eyes)",
    "Silver Pathfinder (Orange Eyes)": "Silver Pathfinder (Orange Eyes)",
    "Silver Pathfinder (Red Eyes)": "Silver Pathfinder (Red Eyes)",
    "Silver Pathfinder (Purple Eyes)": "Silver Pathfinder (Purple Eyes)",

    "Bronze Pathfinder (Blue Eyes)": "Bronze Pathfinder (Blue Eyes)",
    "Bronze Pathfinder (Orange Eyes)": "Bronze Pathfinder (Orange Eyes)",
    "Bronze Pathfinder (Red Eyes)": "Bronze Pathfinder (Red Eyes)",
    "Bronze Pathfinder (Purple Eyes)": "Bronze Pathfinder (Purple Eyes)",

    #ANASAZI
    #=============================================================================
    "Gold Anasazi (Blue Eyes)": "Gold Anasazi (Blue Eyes)",
    "Gold Anasazi (Orange Eyes)": "Gold Anasazi (Orange Eyes)",
    "Gold Anasazi (Red Eyes)": "Gold Anasazi (Red Eyes)",
    "Gold Anasazi (Purple Eyes)": "Gold Anasazi (Purple Eyes)",

    "Silver Anasazi (Blue Eyes)": "Silver Anasazi (Blue Eyes)",
    "Silver Anasazi (Orange Eyes)": "Silver Anasazi (Orange Eyes)",
    "Silver Anasazi (Red Eyes)": "Silver Anasazi (Red Eyes)",
    "Silver Anasazi (Purple Eyes)": "Silver Anasazi (Purple Eyes)",

    "Bronze Anasazi (Blue Eyes)": "Bronze Anasazi (Blue Eyes)",
    "Bronze Anasazi (Orange Eyes)": "Bronze Anasazi (Orange Eyes)",
    "Anasazi_Default_Red": "Heads_Anasazi_Default_Red",
    "Bronze Anasazi (Red Eyes)": "Bronze Anasazi (Red Eyes)",

    #ENFORCER
    #=============================================================================
    "Titanium Enforcer (Blue Eyes)": "Titanium Enforcer (Blue Eyes)",
    "Titanium Enforcer (Orange Eyes)": "Titanium Enforcer (Orange Eyes)",
    "Titanium Enforcer (Purple Eyes)": "Titanium Enforcer (Purple Eyes)",
    "Titanium Enforcer (Red Eyes)": "Titanium Enforcer (Red Eyes)",

    "Gold Enforcer (Blue Eyes)": "Gold Enforcer (Blue Eyes)",
    "Gold Enforcer (Orange Eyes)": "Gold Enforcer (Orange Eyes)",
    "Gold Enforcer (Purple Eyes)": "Gold Enforcer (Purple Eyes)",
    "Gold Enforcer (Red Eyes)": "Gold Enforcer (Red Eyes)",

    "Silver Enforcer (Blue Eyes)": "Silver Enforcer (Blue Eyes)",
    "Silver Enforcer (Orange Eyes)": "Silver Enforcer (Orange Eyes)",
    "Silver Enforcer (Purple Eyes)": "Silver Enforcer (Purple Eyes)",
    "Silver Enforcer (Red Eyes)": "Silver Enforcer (Red Eyes)",

    #DEPUTY
    #=============================================================================
    "Gold Deputy": "Gold Deputy",

    "Silver Deputy (Blue Eyes)": "Silver Deputy (Blue Eyes)",
    "Silver Deputy (Orange Eyes)": "Silver Deputy (Orange Eyes)",
    "Silver Deputy (Purple Eyes)": "Silver Deputy (Purple Eyes)",
    "Silver Deputy (Red Eyes)": "Silver Deputy (Red Eyes)",

    #ONI
    #=============================================================================
    "Bronze Oni (Blue Eyes)": "Bronze Oni (Blue Eyes)",
    "Bronze Oni (Orange Eyes)": "Bronze Oni (Orange Eyes)",
    "Bronze Oni (Purple Eyes)": "Bronze Oni (Purple Eyes)",
    "Bronze Oni (Red Eyes)": "Bronze Oni (Red Eyes)",

    "Gold Oni (Blue Eyes)": "Gold Oni (Blue Eyes)",
    "Gold Oni (Orange Eyes)": "Gold Oni (Orange Eyes)",
    "Gold Oni (Purple Eyes)": "Gold Oni (Purple Eyes)",
    "Gold Oni (Red Eyes)": "Gold Oni (Red Eyes)",

    "Silver Oni (Blue Eyes)": "Silver Oni (Blue Eyes)",
    "Silver Oni (Orange Eyes)": "Silver Oni (Orange Eyes)",
    "Silver Oni (Purple Eyes)": "Silver Oni (Purple Eyes)",
    "Silver Oni (Red Eyes)": "Silver Oni (Red Eyes)",

    #SCOUT
    #=============================================================================
    "Gold Scout": "Gold Scout",
    "Gold Scout w/Glasses": "Gold Scout w/Glasses",

    "Brass Scout": "Brass Scout",
    "Brass Scout w/Glasses": "Brass Scout w/Glasses",

    "Bronze Scout": "Bronze Scout",
    "Bronze Scout w/Glasses": "Bronze Scout w/Glasses",

    "Silver Scout": "Silver Scout",

    "Brass Scout w/Steampunk Goggles": "Brass Scout w/Steampunk Goggles",
    "Silver Scout w/Steampunk Goggles": "Silver Scout w/Steampunk Goggles",
}

hat = {
    "Southwest (Tan)": "Southwest (Tan)",
    "Southwest (Brown)": "Southwest (Brown)",
    "McClintock (Brown)": "McClintock (Brown)",
    "McClintock (Black)": "McClintock (Black)",
    "Josey": "Hat_Josey",
    "Brimley": "Brimley",
    "Raven": "Raven",
    "Ninja": "Ninja"
}

back = {
  "Bandolier (Gold)": "Bandolier (Gold)",
  "Bandolier (Gold w/Rifle)": "Bandolier (Gold w/Rifle)",
  "Bandolier (Gold w/Katana)": "Bandolier (Gold w/Katana)",
  "Bandolier (Gold w/Knife & Rifle)": "Bandolier (Gold w/Knife & Rifle)",
  "Bandolier (Gold w/Knife & Katana)": "Bandolier (Gold w/Knife & Katana)",
  "Bandolier (Silver)": "Bandolier (Silver)",
  "Bandolier (Silver w/Rifle)": "Bandolier (Silver w/Rifle)",
  "Bandolier (Silver w/Katana)": "Bandolier (Silver w/Katana)",
  "GasMask": "GasMask",
}

accessory = {
    "Gauntlet": "Gauntlet",
    "Epaulette": "Epaulette"
}

torso = {
  "Bandana (Apocalypse)": "Bandana (Apocalypse)",
  "Bandana (Josey)": "Bandana (Josey)",
  "Utility Belt (Apocalypse)": "Utility Belt (Apocalypse)",
  "Utility Belt (Josey)": "Utility Belt (Josey)",
  "Plackart (Apocalypse)": "Plackart (Apocalypse)",
  "Plackart (Josey)": "Plackart (Josey)",
  "Utility Belt (Apocalypse w/Bandana)": "Utility Belt (Apocalypse w/Bandana)",
  "Utility Belt (Josey w/Bandana)": "Utility Belt (Josey w/Bandana)",
  "Plackart (Apocalypse w/Bandana)": "Plackart (Apocalypse w/Bandana)",
  "Plackart (Josey w/Bandana)": "Plackart (Josey w/Bandana)",
  "Plackart (Apocalypse w/Utility Belt)": "Plackart (Apocalypse w/Utility Belt)",
  "Plackart (Josey w/Utility Belt)": "Plackart (Josey w/Utility Belt)",
  "Bundle (Apocalypse)": "Bundle (Apocalypse)",
  "Bundle (Josey)": "Bundle (Josey)",
  "Bundle (Classic)": "Bundle (Classic)",
  "Bundle (Classic Red)": "Bundle (Classic Red)",
  "Plackart (Black Ninja)": "Plackart (Black Ninja)",
  "Plackart (Green Ninja)": "Plackart (Green Ninja)",
}

arms = {
  "Robot (Bronze)": "Robot (Bronze)",
  "Robot (Gold)": "Robot (Gold)",
  "Robot (Silver)": "Robot (Silver)",
  "Black w/Bronze Gloves": "Black w/Bronze Gloves",
  "Tan w/Titanium Gloves": "Tan w/Titanium Gloves",
  "White w/Gold Gloves": "White w/Gold Gloves",
  "White w/Red Gloves": "White w/Red Gloves",
  "Black w/Copper (L) Bronze Prosthesis (R)": "Black w/Copper (L) Bronze Prosthesis (R)",
  "Black w/Copper (L) Gold Prosthesis (R)": "Black w/Copper (L) Gold Prosthesis (R)",
  "Black w/Copper (L) Silver Prosthesis (R)": "Black w/Copper (L) Silver Prosthesis (R)",
  "White w/Titanium (L) Bronze Prosthesis (R)": "White w/Titanium (L) Bronze Prosthesis (R)",
  "White w/Titanium (L) Gold Prosthesis (R)": "White w/Titanium (L) Gold Prosthesis (R)",
  "White w/Titanium (L) Silver Prosthesis (R)": "White w/Titanium (L) Silver Prosthesis (R)",
  "Tan w/Titanium (L) Bronze Prosthesis (R)": "Tan w/Titanium (L) Bronze Prosthesis (R)",
  "Tan w/Titanium (L) Gold Prosthesis (R)": "Tan w/Titanium (L) Gold Prosthesis (R)",
  "Tan w/Titanium (L) Silver Prosthesis (R)": "Tan w/Titanium (L) Silver Prosthesis (R)",
  "White w/Red (L) Bronze Prosthesis (R)": "White w/Red (L) Bronze Prosthesis (R)",
  "White w/Red (L) Gold Prosthesis (R)": "White w/Red (L) Gold Prosthesis (R)",
  "White w/Red (L) Silver Prosthesis (R)": "White w/Red (L) Silver Prosthesis (R)",
  "Bronze Prosthesis (L) Black w/Copper (R)": "Bronze Prosthesis (L) Black w/Copper (R)",
  "Gold Prosthesis (L) Black w/Copper (R)": "Gold Prosthesis (L) Black w/Copper (R)",
  "Silver Prosthesis (L) Black w/Copper (R)": "Silver Prosthesis (L) Black w/Copper (R)",
  "Bronze Prosthesis (L) White w/Titanium (R)": "Bronze Prosthesis (L) White w/Titanium (R)",
  "Gold Prosthesis (L) White w/Titanium (R)": "Gold Prosthesis (L) White w/Titanium (R)",
  "Silver Prosthesis (L) White w/Titanium (R)": "Silver Prosthesis (L) White w/Titanium (R)",
  "Bronze Prosthesis (L) Tan w/Titanium (R)": "Bronze Prosthesis (L) Tan w/Titanium (R)",
  "Gold Prosthesis (L) Tan w/Titanium (R)": "Gold Prosthesis (L) Tan w/Titanium (R)",
  "Silver Prosthesis (L) Tan w/Titanium (R)": "Silver Prosthesis (L) Tan w/Titanium (R)",
  "Bronze Prosthesis (L) White w/Red (R)": "Bronze Prosthesis (L) White w/Red (R)",
  "Gold Prosthesis (L) White w/Red (R)": "Gold Prosthesis (L) White w/Red (R)",
  "Silver Prosthesis (L) White w/Red (R)": "Silver Prosthesis (L) White w/Red (R)",
}

garment = {
    "Jacket (Blue)": "Jacket (Blue)",
    "Jacket (Black)": "Jacket (Black)",
    "Duster (Brown)": "Duster (Brown)",
    "Duster (Red)": "Duster (Red)",
    "Poncho": "Poncho",
    "Cape": "Cape",
    "Cape (w/Gauntlet)": "Cape (w/Gauntlet)"
}

boots = {
  "Murrieta": "Murrieta",
  "Hickok": "Hickok",
  "Rogers": "Rogers",
  "Eastwood": "Eastwood",
  "Steampunk": "Steampunk Boots",
  "Raven": "Raven",
  "Ninja": "Ninja",
}

guns = {
  "Bone (Left)": "Bone (Left)",
  "Tungsten (Left)": "Tungsten (Left)",
  "Bone (Right)": "Bone (Right)",
  "Tungsten (Right)": "Tungsten (Right)",
  "Gold (Left)": "Gold (Left)",
  "Gold (Right)": "Gold (Right)",
  "Tungsten (Left & Right)": "Tungsten (Left & Right)",
  "Gold (Left & Right)": "Gold (Left & Right)",
  "Mahogany (Left & Right)": "Mahogany (Left & Right)",
  "Steampunk (Left & Right)": "Steampunk (Left & Right)",
  "Bone (Left, Right, & Concealed)": "Bone (Left, Right, & Concealed)",
  "Gold (Left, Right, & Concealed)": "Gold (Left, Right, & Concealed)",
  "Doc Holliday (Left)": "Doc Holliday (Left)",
  "Doc Holliday (Right)": "Doc Holliday (Right)",
}

background = {
    "BarnDoor": 1,
    "Jail": 2,
    "GunShots": 3,
    "Prairie": 4,
    "OnFence": 5,
    "Downtown": 6,
    "Cactus": 7,
    "Saloon": 8,
    "Campfire": 9
}