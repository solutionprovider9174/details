import fs from "fs";

const rarities = [
  { value: "Common", weight: 1, modifier: 0 },
  { value: "Uncommon", weight: 0.3333, modifier: 0.1 },
  { value: "Rare", weight: 0.1, modifier: 0.2 },
  { value: "Epic", weight: 0.03333, modifier: 0.25 },
  { value: "Heroic", weight: 0.01, modifier: 0.3 },
  { value: "Legendary", weight: 0.003333, modifier: 0.35 },
  { value: "Godlike", weight: 0.001, modifier: 0.4 },
];

const rarityModifier = [
  { value: "Common", rarity: rarities[0] },
  { value: "Uncommon", rarity: rarities[1] },
  { value: "Rare", rarity: rarities[2] },
  { value: "Epic", rarity: rarities[3] },
  { value: "Heroic", rarity: rarities[4] },
  { value: "Legendary", rarity: rarities[5] },
  { value: "Godlike", rarity: rarities[6] },
];

const Outfit = [
  { value: "Yuma", rarity: rarities[0] },
  { value: "Tombstone", rarity: rarities[2] },
  { value: "Durango (Dual Brass Belt)", rarity: rarities[1] },
  { value: "Durango (Dual Silver Belt)", rarity: rarities[1] },
  { value: "Escalante (Dual Brass Belt)", rarity: rarities[1] },
  { value: "Escalante (Dual Silver Belt)", rarity: rarities[1] },
  { value: "Sedona (Dual Brass Belt)", rarity: rarities[0] },
  { value: "Sedona (Dual Silver Belt)", rarity: rarities[0] },
];

const Head = [
  { value: "Gold Desperado (Blue Eyes)", rarity: rarities[0] },
  { value: "Gold Desperado (Orange Eyes)", rarity: rarities[0] },
  { value: "Gold Desperado (Red Eyes)", rarity: rarities[0] },
  { value: "Gold Desperado (Purple Eyes)", rarity: rarities[0] },

  { value: "Silver Desperado (Blue Eyes)", rarity: rarities[0] },
  { value: "Silver Desperado (Orange Eyes)", rarity: rarities[0] },
  { value: "Silver Desperado (Red Eyes)", rarity: rarities[0] },
  { value: "Silver Desperado (Purple Eyes)", rarity: rarities[0] },

  { value: "Bronze Desperado (Blue Eyes)", rarity: rarities[0] },
  { value: "Bronze Desperado (Orange Eyes)", rarity: rarities[0] },
  { value: "Bronze Desperado (Red Eyes)", rarity: rarities[0] },
  { value: "Bronze Desperado (Purple Eyes)", rarity: rarities[0] },

  { value: "Bronze Oni (Blue Eyes)", rarity: rarities[3] },
  { value: "Bronze Oni (Orange Eyes)", rarity: rarities[3] },
  { value: "Bronze Oni (Purple Eyes)", rarity: rarities[3] },
  { value: "Bronze Oni (Red Eyes)", rarity: rarities[4] },

  { value: "Gold Oni (Blue Eyes)", rarity: rarities[3] },
  { value: "Gold Oni (Orange Eyes)", rarity: rarities[3] },
  { value: "Gold Oni (Purple Eyes)", rarity: rarities[3] },
  { value: "Gold Oni (Red Eyes)", rarity: rarities[4] },

  { value: "Silver Oni (Blue Eyes)", rarity: rarities[3] },
  { value: "Silver Oni (Orange Eyes)", rarity: rarities[3] },
  { value: "Silver Oni (Purple Eyes)", rarity: rarities[3] },
  { value: "Silver Oni (Red Eyes)", rarity: rarities[3] },

  { value: "Gold Pathfinder (Blue Eyes)", rarity: rarities[1] },
  { value: "Gold Pathfinder (Orange Eyes)", rarity: rarities[1] },
  { value: "Gold Pathfinder (Red Eyes)", rarity: rarities[1] },
  { value: "Gold Pathfinder (Purple Eyes)", rarity: rarities[1] },

  { value: "Silver Pathfinder (Blue Eyes)", rarity: rarities[1] },
  { value: "Silver Pathfinder (Orange Eyes)", rarity: rarities[1] },
  { value: "Silver Pathfinder (Red Eyes)", rarity: rarities[1] },
  { value: "Silver Pathfinder (Purple Eyes)", rarity: rarities[1] },

  { value: "Bronze Pathfinder (Blue Eyes)", rarity: rarities[1] },
  { value: "Bronze Pathfinder (Orange Eyes)", rarity: rarities[1] },
  { value: "Bronze Pathfinder (Red Eyes)", rarity: rarities[1] },
  { value: "Bronze Pathfinder (Purple Eyes)", rarity: rarities[1] },

  { value: "Gold Anasazi (Blue Eyes)", rarity: rarities[2] },
  { value: "Gold Anasazi (Orange Eyes)", rarity: rarities[2] },
  { value: "Gold Anasazi (Red Eyes)", rarity: rarities[2] },
  { value: "Gold Anasazi (Purple Eyes)", rarity: rarities[2] },

  { value: "Silver Anasazi (Blue Eyes)", rarity: rarities[2] },
  { value: "Silver Anasazi (Orange Eyes)", rarity: rarities[2] },
  { value: "Silver Anasazi (Red Eyes)", rarity: rarities[2] },
  { value: "Silver Anasazi (Purple Eyes)", rarity: rarities[2] },

  { value: "Bronze Anasazi (Blue Eyes)", rarity: rarities[2] },
  { value: "Bronze Anasazi (Orange Eyes)", rarity: rarities[2] },
  { value: "Bronze Anasazi (Red Eyes)", rarity: rarities[2] },
  { value: "Bronze Anasazi (Purple Eyes)", rarity: rarities[2] },

  { value: "Gold Deputy", rarity: rarities[1] },

  { value: "Silver Deputy (Blue Eyes)", rarity: rarities[1] },
  { value: "Silver Deputy (Orange Eyes)", rarity: rarities[1] },
  { value: "Silver Deputy (Purple Eyes)", rarity: rarities[1] },
  { value: "Silver Deputy (Red Eyes)", rarity: rarities[1] },
  
  { value: "Titanium Enforcer (Blue Eyes)", rarity: rarities[2] },
  { value: "Titanium Enforcer (Orange Eyes)", rarity: rarities[2] },
  { value: "Titanium Enforcer (Purple Eyes)", rarity: rarities[2] },
  { value: "Titanium Enforcer (Red Eyes)", rarity: rarities[2] },

  { value: "Gold Enforcer (Blue Eyes)", rarity: rarities[3] },
  { value: "Gold Enforcer (Orange Eyes)", rarity: rarities[3] },
  { value: "Gold Enforcer (Purple Eyes)", rarity: rarities[3] },
  { value: "Gold Enforcer (Red Eyes)", rarity: rarities[3] },

  { value: "Silver Enforcer (Blue Eyes)", rarity: rarities[2] },
  { value: "Silver Enforcer (Orange Eyes)", rarity: rarities[2] },
  { value: "Silver Enforcer (Purple Eyes)", rarity: rarities[2] },
  { value: "Silver Enforcer (Red Eyes)", rarity: rarities[2] },

  { value: "Gold Scout", rarity: rarities[3] },
  { value: "Gold Scout w/Glasses", rarity: rarities[3] },
  { value: "Brass Scout", rarity: rarities[3] },
  { value: "Brass Scout w/Glasses", rarity: rarities[3] },

  { value: "Bronze Scout", rarity: rarities[3] },
  { value: "Bronze Scout w/Glasses", rarity: rarities[3] },

  { value: "Brass Scout w/Steampunk Goggles", rarity: rarities[3] },
  { value: "Silver Scout w/Steampunk Goggles", rarity: rarities[4] },

  { value: "Silver Scout", rarity: rarities[3] },

];

const Hat = [
  { value: "Southwest (Tan)", rarity: rarities[1] },
  { value: "Southwest (Brown)", rarity: rarities[1] },
  { value: "McClintock (Black)", rarity: rarities[0] },
  { value: "McClintock (Brown)", rarity: rarities[0] },
  { value: "Josey", rarity: rarities[1] },
  { value: "Brimley", rarity: rarities[1] },
  { value: "Raven", rarity: rarities[2] },
  { value: "Ninja", rarity: rarities[2] },
];

const Guns = [
  { value: "Bone (Left)", rarity: rarities[0] },
  { value: "Tungsten (Left)", rarity: rarities[0] },
  { value: "Gold (Left)", rarity: rarities[0] },
  { value: "Bone (Right)", rarity: rarities[0] },
  { value: "Tungsten (Right)", rarity: rarities[0] },
  { value: "Gold (Right)", rarity: rarities[0] },
  { value: "Tungsten (Left & Right)", rarity: rarities[1] },
  { value: "Gold (Left & Right)", rarity: rarities[1] },
  { value: "Mahogany (Left & Right)", rarity: rarities[1] },
  { value: "Steampunk (Left & Right)", rarity: rarities[1] },
  { value: "Bone (Left, Right, & Concealed)", rarity: rarities[3] },
  { value: "Gold (Left, Right, & Concealed)", rarity: rarities[3] },
  { value: "Doc Holliday (Left)", rarity: rarities[5] },
  { value: "Doc Holliday (Right)", rarity: rarities[5] },
];

const Back = [
  { value: "Bandolier (Gold)", rarity: rarities[1] },
  { value: "Bandolier (Gold w/Rifle)", rarity: rarities[1] },
  { value: "Bandolier (Gold w/Katana)", rarity: rarities[2] },
  { value: "Bandolier (Gold w/Knife & Rifle)", rarity: rarities[1] },
  { value: "Bandolier (Gold w/Knife & Katana)", rarity: rarities[6] },
  { value: "Bandolier (Silver)", rarity: rarities[0] },
  { value: "Bandolier (Silver w/Rifle)", rarity: rarities[0] },
  { value: "Bandolier (Silver w/Katana)", rarity: rarities[0] },
  { value: "GasMask", rarity: rarities[5] },
];

const Accessory = [
  { value: "Gauntlet", rarity: rarities[2] },
  { value: "Epaulette", rarity: rarities[2] },
];

const Torso = [
  { value: "Bandana (Apocalypse)", rarity: rarities[0] },
  { value: "Bandana (Josey)", rarity: rarities[0] },
  { value: "Utility Belt (Apocalypse)", rarity: rarities[0] },
  { value: "Utility Belt (Josey)", rarity: rarities[0] },
  { value: "Plackart (Apocalypse)", rarity: rarities[0] },
  { value: "Plackart (Josey)", rarity: rarities[0] },
  { value: "Utility Belt (Apocalypse w/Bandana)", rarity: rarities[1] },
  { value: "Utility Belt (Josey w/Bandana)", rarity: rarities[1] },
  { value: "Plackart (Apocalypse w/Bandana)", rarity: rarities[1] },
  { value: "Plackart (Josey w/Bandana)", rarity: rarities[1] },
  { value: "Plackart (Apocalypse w/Utility Belt)", rarity: rarities[1] },
  { value: "Plackart (Josey w/Utility Belt)", rarity: rarities[1] },
  { value: "Bundle (Apocalypse)", rarity: rarities[2] },
  { value: "Bundle (Josey)", rarity: rarities[2] },
  { value: "Bundle (Classic)", rarity: rarities[2] },
  { value: "Bundle (Classic Red)", rarity: rarities[2] },
  { value: "Plackart (Black Ninja)", rarity: rarities[3] },
  { value: "Plackart (Green Ninja)", rarity: rarities[3] },
];

const Arms = [
  { value: "Robot (Bronze)", rarity: rarities[0] },
  { value: "Robot (Gold)", rarity: rarities[0] },
  { value: "Robot (Silver)", rarity: rarities[0] },
  { value: "Black w/Bronze Gloves", rarity: rarities[0] },
  { value: "Tan w/Titanium Gloves", rarity: rarities[0] },
  { value: "White w/Gold Gloves", rarity: rarities[0] },
  { value: "White w/Red Gloves", rarity: rarities[1] },
  { value: "Black w/Copper (L) Bronze Prosthesis (R)", rarity: rarities[0] },
  { value: "Black w/Copper (L) Gold Prosthesis (R)", rarity: rarities[0] },
  { value: "Black w/Copper (L) Silver Prosthesis (R)", rarity: rarities[0] },
  { value: "White w/Titanium (L) Bronze Prosthesis (R)", rarity: rarities[1] },
  { value: "White w/Titanium (L) Gold Prosthesis (R)", rarity: rarities[1] },
  { value: "White w/Titanium (L) Silver Prosthesis (R)", rarity: rarities[1] },
  { value: "Tan w/Titanium (L) Bronze Prosthesis (R)", rarity: rarities[1] },
  { value: "Tan w/Titanium (L) Gold Prosthesis (R)", rarity: rarities[1] },
  { value: "Tan w/Titanium (L) Silver Prosthesis (R)", rarity: rarities[1] },
  { value: "White w/Red (L) Bronze Prosthesis (R)", rarity: rarities[2] },
  { value: "White w/Red (L) Gold Prosthesis (R)", rarity: rarities[2] },
  { value: "White w/Red (L) Silver Prosthesis (R)", rarity: rarities[2] },
  { value: "Bronze Prosthesis (L) Black w/Copper (R)", rarity: rarities[0] },
  { value: "Gold Prosthesis (L) Black w/Copper (R)", rarity: rarities[0] },
  { value: "Silver Prosthesis (L) Black w/Copper (R)", rarity: rarities[0] },
  { value: "Bronze Prosthesis (L) White w/Titanium (R)", rarity: rarities[1] },
  { value: "Gold Prosthesis (L) White w/Titanium (R)", rarity: rarities[1] },
  { value: "Silver Prosthesis (L) White w/Titanium (R)", rarity: rarities[1] },
  { value: "Bronze Prosthesis (L) Tan w/Titanium (R)", rarity: rarities[1] },
  { value: "Gold Prosthesis (L) Tan w/Titanium (R)", rarity: rarities[1] },
  { value: "Silver Prosthesis (L) Tan w/Titanium (R)", rarity: rarities[1] },
  { value: "Bronze Prosthesis (L) White w/Red (R)", rarity: rarities[2] },
  { value: "Gold Prosthesis (L) White w/Red (R)", rarity: rarities[2] },
  { value: "Silver Prosthesis (L) White w/Red (R)", rarity: rarities[2] },
];

const Garment = [
  { value: "Jacket (Blue)", rarity: rarities[2] },
  { value: "Jacket (Black)", rarity: rarities[2] },
  { value: "Duster (Brown)", rarity: rarities[2] },
  { value: "Duster (Red)", rarity: rarities[2] },
  { value: "Poncho", rarity: rarities[2] },
  { value: "Cape", rarity: rarities[2] },
  { value: "Cape (w/Gauntlet)", rarity: rarities[2] },
];

const Boots = [
  { value: "Murrieta", rarity: rarities[0] },
  { value: "Hickok", rarity: rarities[0] },
  { value: "Rogers", rarity: rarities[0] },
  { value: "Eastwood", rarity: rarities[0] },
  { value: "Steampunk", rarity: rarities[1] },
  { value: "Raven", rarity: rarities[1] },
  { value: "Ninja", rarity: rarities[1] },
];

const Backgrounds = [
  { value: "BarnDoor", rarity: rarities[0] },
  { value: "Jail", rarity: rarities[0] },
  { value: "GunShots", rarity: rarities[3] },
  { value: "Prairie", rarity: rarities[0] },
  { value: "OnFence", rarity: rarities[1] },
  { value: "Downtown", rarity: rarities[1] },
  { value: "Cactus", rarity: rarities[2] },
  { value: "Saloon", rarity: rarities[1] },
  { value: "Campfire", rarity: rarities[2] },
];

const getTableOutput = (randomNumber, table, min = 0) => {
  let totalVal;
  totalVal = table.reduce((a, b) => a + b.rarity.weight, 0);

  const adjustedVal = totalVal - min;
  const roll = randomNumber * adjustedVal + min;

  for (let i = 0; i < table.length; i++) {
    if (i === 0) table[i]["min"] = 0;
    else
      table[i]["min"] = table
        .slice(0, i)
        .reduce((a, b) => a + b.rarity.weight, 0);
    if (i === table.length - 1) table[i]["max"] = totalVal + 1000;
    else
      table[i]["max"] = table
        .slice(0, i + 1)
        .reduce((a, b) => a + b.rarity.weight, 0);
  }

  const output = table.find((x) => roll >= x["min"] && roll <= x.max);

  return output;
};

let alreadyCreated = [];

function generateSaberStats() {
  // Rarity modifier
  let rarity = getTableOutput(Math.random(), rarityModifier);
  const fixedRarityModifier = rarities.find(
    (x) => x.value === rarity.value
  ).modifier;
  // BladeColor
  const outfit = getTableOutput(
    Math.random(),
    Outfit,
    fixedRarityModifier
  );

  const head = getTableOutput(Math.random(), Head, fixedRarityModifier);

  const hat = getTableOutput(Math.random(), Hat, fixedRarityModifier);

  const boots = getTableOutput(Math.random(), Boots, fixedRarityModifier);

  const back = getTableOutput(Math.random(), Back, fixedRarityModifier);

  const accessory = getTableOutput(
    Math.random(),
    Accessory,
    fixedRarityModifier
  );

  const torso = getTableOutput(Math.random(), Torso, fixedRarityModifier);

  const arms = getTableOutput(Math.random(), Arms, fixedRarityModifier);

  const garment =
    back.value != "GasMask"
      ? getTableOutput(Math.random(), Garment, fixedRarityModifier)
      : getTableOutput(
          Math.random(),
          [
            { value: "ButtonedJacket_Blue", rarity: rarities[2] },
            { value: "ButtonedJacket_Black", rarity: rarities[4] },
          ],
          fixedRarityModifier
        );
  const backgrounds = getTableOutput(
    Math.random(),
    Backgrounds,
    fixedRarityModifier
  );

  const guns = getTableOutput(Math.random(), Guns, fixedRarityModifier);

  let hash =
    rarity.value +
    " | " +
    outfit.value +
    " | " +
    head.value +
    " | " +
    hat.value;

  const cowboy = {
    description: "",
    external_url: "",
    image: "",
    name: hash,
    attributes: [
      {
        trait_type: "outfit",
        value: outfit.value,
      },
      {
        trait_type: "head",
        value: head.value,
      },
      {
        trait_type: "hat",
        value: hat.value,
      },
      {
        trait_type: "boots",
        value: boots.value,
      },
      {
        trait_type: "back",
        value: back.value,
      },
      {
        trait_type: "accessory",
        value: accessory.value,
      },
      {
        trait_type: "torso",
        value: torso.value,
      },
      {
        trait_type: "arms",
        value: arms.value,
      },
      {
        trait_type: "garment",
        value: garment.value,
      },
      {
        trait_type: "guns",
        value: guns.value,
      },
      {
        trait_type: "backgrounds",
        value: backgrounds.value,
      },
    ],
  };

  alreadyCreated.push(cowboy);

  return cowboy;
}

const series = [];
// How many cowboys to generate in the series?
const seriesSize = 100;

for (let i = 0; i < seriesSize; i++) {
  const cowboy = generateSaberStats();

  const alreadyExists =
    alreadyCreated.filter((item) => cowboy.name == item.name).length > 0;

  if (!cowboy.duplicate) series.push(cowboy);
}

const seriesFiltered = [];
series.forEach((cowboy) => {
  const newSaber = { ...cowboy };
  delete newSaber["duplicate"];
  delete newSaber["hash"];
  delete newSaber["rarity"];
  seriesFiltered.push(newSaber);
});

const data = JSON.stringify(seriesFiltered);

fs.writeFileSync("data.json", data);

console.log(
  "Made a series with",
  seriesSize,
  "attempted. Generated",
  seriesFiltered.length,
  "cowboys"
);
// if (seriesFiltered.length < seriesSize) {
//   console.log(
//     "Try adding more unique options to generators to increase likelihood of successful generation"
//   );
// }
// console.log(
//   "Commons",
//   series.filter((cowboy) => cowboy.rarity === "Common").length
// );
// console.log(
//   "Uncommons",
//   series.filter((cowboy) => cowboy.rarity === "Uncommon").length
// );
// console.log(
//   "Rares",
//   series.filter((cowboy) => cowboy.rarity === "Rare").length
// );
// console.log(
//   "Epics",
//   series.filter((cowboy) => cowboy.rarity === "Epic").length
// );
// console.log(
//   "Heroics",
//   series.filter((cowboy) => cowboy.rarity === "Heroic").length
// );
// console.log(
//   "Legendaries",
//   series.filter((cowboy) => cowboy.rarity === "Legendary").length
// );
// console.log(
//   "Godlikes",
//   series.filter((cowboy) => cowboy.rarity === "Godlike").length
// );

// console.log(
//   "Raven_Hat",
//   series.filter((cowboy) => cowboy.hat.includes("Raven")).length
// );
// console.log(
//   "Raven_Boots",
//   series.filter((cowboy) => cowboy.boots.includes("Raven")).length
// );
// console.log(
//   "Raven_All",
//   series.filter(
//     (cowboy) => cowboy.boots.includes("Raven") && cowboy.hat.includes("Raven")
//   ).length
// );

// console.log(
//   "Onis",
//   series.filter((cowboy) => cowboy.head.includes("Oni")).length
// );
// console.log(
//   "Oni_WhiteEyes",
//   series.filter((cowboy) => cowboy.head.includes("Oni_WhiteEyes")).length
// );
